import React from "react";
const GeneratedComponent = () => {
  return (
    <div
      id="_25_99_List"
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(161, 207, 222, 1.00)",
        height: "100vh",
        width: "100%",
      }}
    >
      <div
        id="_25_155_image_4"
        style={{
          position: "absolute",
          background:
            "linear-gradient(0deg, rgba(0, 0, 0, 0.54)0%, rgba(0, 0, 0, 0.54)100%), url(https://mabel-cdn.platui.com/api/v1/transform/s3?projectId=a9ad257e-3683-40a9-bd79-f84fcc135391&imageHash=4996c0ee38d3af92a33271206728ba99a788dc50&imageTransform=1.000000000000,0.000000000000,-0.000000000000;0.000000000000,0.635416686535,0.213467508554) 100% / cover no-repeat",
          filter:
            "drop-shadow(0.0px 7.0px 8.399999618530273px 0.0px rgba(0, 0, 0, 0.25))",
          height: "610.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "-242.0px",
        }}
      ></div>

      <div
        id="_25_102_Rectangle_7"
        style={{
          position: "absolute",
          background: "rgba(26, 40, 53, 1.00)",
          height: "98.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "0.0px",
        }}
      ></div>

      <span
        id="Intell-I-Invest"
        style={{
          color: "#e9f9f9ff",
          fontFamily: "Inter",
          fontSize: "35.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "42.0px",
          width: "225.0px",
          position: "absolute",
          left: "123.0px",
          top: "29.0px",
        }}
      >
        Intell-I-Invest
      </span>
      <span
        id="Home"
        style={{
          color: "#e9f9f9ff",
          fontFamily: "Inter",
          fontSize: "25.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "23.0px",
          width: "74.0px",
          position: "absolute",
          left: "926.0px",
          top: "37.0px",
        }}
      >
        Home
      </span>
      <span
        id="About_Us"
        style={{
          color: "#e9f9f9ff",
          fontFamily: "Inter",
          fontSize: "25.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "23.0px",
          width: "112.0px",
          position: "absolute",
          left: "1065.0px",
          top: "38.0px",
        }}
      >
        About Us
      </span>
      <span
        id="Contact_Us"
        style={{
          color: "#e9f9f9ff",
          fontFamily: "Inter",
          fontSize: "25.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "23.0px",
          width: "155.0px",
          position: "absolute",
          left: "1223.0px",
          top: "37.0px",
        }}
      >
        Contact Us
      </span>
      <div
        id="_25_108_Ellipse_1"
        style={{
          position: "absolute",
          background: "rgba(233, 249, 249, 1.00)",
          height: "65.00000762939453px",
          width: "65.00000762939453px",
          borderRadius: "50%",
          left: "46.0px",
          top: "16.0px",
        }}
      ></div>

      <div
        id="_25_109_bgremove-Photoroom_1"
        style={{
          position: "absolute",
          background:
            "url(https://mabel-cdn.platui.com/api/v1/transform/s3?projectId=a9ad257e-3683-40a9-bd79-f84fcc135391&imageHash=96562446873002289b644565cbeea844e4731e8a&imageTransform=0.589814841747,0.000000000000,0.205555558205;0.000000000000,0.563888907433,0.203703701496) 100% / cover no-repeat",
          height: "44.200008392333984px",
          width: "46.14998245239258px",
          left: "55.100308418273926px",
          top: "26.400399208068848px",
        }}
      ></div>

      <span
        id="Sector___Iron_Industry"
        style={{
          color: "#ffffffff",
          fontFamily: "Inter",
          fontSize: "60.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "162.0px",
          width: "790.0px",
          position: "absolute",
          left: "65.0px",
          top: "138.0px",
        }}
      >
        Sector &gt; Iron Industry
      </span>
      <span
        id="Sr__No"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "27.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "119.0px",
          position: "absolute",
          left: "79.0px",
          top: "451.0px",
        }}
      >
        Sr. No
      </span>
      <span
        id="Company_Name"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "27.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "627.0px",
          position: "absolute",
          left: "198.0px",
          top: "451.0px",
        }}
      >
        Company Name
      </span>
      <span
        id="Success_Rate"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "27.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "249.0px",
          position: "absolute",
          left: "825.0px",
          top: "451.0px",
        }}
      >
        Success Rate
      </span>
      <span
        id="Risk_Factor"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "27.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "253.0px",
          position: "absolute",
          left: "1074.0px",
          top: "451.0px",
        }}
      >
        Risk Factor
      </span>
      <span
        id="_1_"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "119.0px",
          position: "absolute",
          left: "79.0px",
          top: "543.0px",
        }}
      >
        1.
      </span>
      <span
        id="ABC"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "627.0px",
          position: "absolute",
          left: "198.0px",
          top: "543.0px",
        }}
      >
        ABC
      </span>
      <span
        id="_94_"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "249.0px",
          position: "absolute",
          left: "825.0px",
          top: "543.0px",
        }}
      >
        94%
      </span>
      <span
        id="Medium"
        style={{
          color: "#fdf500ff",
          fontFamily: "Inter",
          fontSize: "27.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "253.0px",
          position: "absolute",
          left: "1074.0px",
          top: "539.0px",
        }}
      >
        Medium
      </span>
      <span
        id="_2_"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "119.0px",
          position: "absolute",
          left: "78.0px",
          top: "632.0px",
        }}
      >
        2.
      </span>
      <span
        id="DEF"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "627.0px",
          position: "absolute",
          left: "197.0px",
          top: "632.0px",
        }}
      >
        DEF
      </span>
      <span
        id="_83_"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "249.0px",
          position: "absolute",
          left: "824.0px",
          top: "632.0px",
        }}
      >
        83%
      </span>
      <span
        id="High"
        style={{
          color: "#fd0000ff",
          fontFamily: "Inter",
          fontSize: "27.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "253.0px",
          position: "absolute",
          left: "1073.0px",
          top: "628.0px",
        }}
      >
        High
      </span>
      <span
        id="_3_"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "119.0px",
          position: "absolute",
          left: "78.0px",
          top: "715.0px",
        }}
      >
        3.
      </span>
      <span
        id="XYZ"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "627.0px",
          position: "absolute",
          left: "197.0px",
          top: "715.0px",
        }}
      >
        XYZ
      </span>
      <span
        id="_72_"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "249.0px",
          position: "absolute",
          left: "824.0px",
          top: "715.0px",
        }}
      >
        72%
      </span>
      <span
        id="Medium"
        style={{
          color: "#fdf500ff",
          fontFamily: "Inter",
          fontSize: "27.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "253.0px",
          position: "absolute",
          left: "1073.0px",
          top: "711.0px",
        }}
      >
        Medium
      </span>
      <span
        id="_4_"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "119.0px",
          position: "absolute",
          left: "78.0px",
          top: "793.0px",
        }}
      >
        4.
      </span>
      <span
        id="LMN"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "627.0px",
          position: "absolute",
          left: "197.0px",
          top: "793.0px",
        }}
      >
        LMN
      </span>
      <span
        id="_60_"
        style={{
          color: "#1a2835ff",
          fontFamily: "Inter",
          fontSize: "22.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "249.0px",
          position: "absolute",
          left: "824.0px",
          top: "793.0px",
        }}
      >
        60%
      </span>
      <span
        id="Low"
        style={{
          color: "#0d8a02ff",
          fontFamily: "Inter",
          fontSize: "27.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "70.0px",
          width: "253.0px",
          position: "absolute",
          left: "1073.0px",
          top: "789.0px",
        }}
      >
        Low
      </span>
      <hr />
      <hr />
      <hr />
      <hr />
      <hr />
    </div>
  );
};

export default GeneratedComponent;
