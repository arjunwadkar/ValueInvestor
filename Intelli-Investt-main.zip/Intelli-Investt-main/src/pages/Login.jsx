import { useNavigate } from "react-router-dom";
import React from "react";
const GeneratedComponent = () => {
  const navigate = useNavigate();

  return (
    <div
      id="_9_40_Desktop_-_3"
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(26, 40, 53, 1.00)",
        height: "100vh",
        width: "100%",
      }}
    >
      <span
        id="Name"
        style={{
          color: "#a1cfdeff",
          fontFamily: "Inter",
          fontSize: "20.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "24.0px",
          width: "56.0px",
          position: "absolute",
          left: "64.0px",
          top: "287.0px",
        }}
      >
        Name
      </span>
      <img
        id="_9_43_Recta"
        src="assets/images/603800741.svg"
        alt="Rectangle_3"
        style={{ position: "absolute", left: "64.0px", top: "323.5px" }}
      />
      <span
        id="E-mail"
        style={{
          color: "#a1cfdeff",
          fontFamily: "Inter",
          fontSize: "20.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "24.0px",
          width: "60.0px",
          position: "absolute",
          left: "64.0px",
          top: "423.0px",
        }}
      >
        E-mail
      </span>
      <img
        id="_9_45_Recta"
        src="assets/images/603800741.svg"
        alt="Rectangle_4"
        style={{ position: "absolute", left: "64.0px", top: "459.5px" }}
      />
      <span
        id="Password"
        style={{
          color: "#a1cfdeff",
          fontFamily: "Inter",
          fontSize: "20.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "24.0px",
          width: "93.0px",
          position: "absolute",
          left: "64.0px",
          top: "554.0px",
        }}
      >
        Password
      </span>
      <span
        id="Remember_Me"
        style={{
          color: "#eefbffff",
          fontFamily: "Inter",
          fontSize: "16.0px",
          fontWeight: "400",
          textAlign: "left",
          height: "19.0px",
          width: "110.0px",
          position: "absolute",
          left: "102.0px",
          top: "693.0px",
        }}
      >
        Remember Me
      </span>
      <img
        id="_9_47_Recta"
        src="assets/images/603800741.svg"
        alt="Rectangle_5"
        style={{ position: "absolute", left: "64.0px", top: "590.5px" }}
      />
      <img
        id="_25_126_Rec"
        src="assets/images/1103939377.svg"
        alt="Rectangle_6"
        onClick={() => navigate("/HomeScreen")}
        style={{
          position: "absolute",
          left: "64.0px",
          top: "766.0px",
          cursor: "pointer",
        }}
      />
      <span
        id="Enter_you_name"
        style={{
          color: "#000000ff",
          fontFamily: "Inter",
          fontSize: "25.0px",
          fontWeight: "400",
          lineHeight: "120%",
          textAlign: "left",
          height: "46.0px",
          width: "370.0px",
          position: "absolute",
          left: "92.0px",
          top: "331.0px",
          opacity: "0.20000000298023224",
        }}
      >
        Enter you name
      </span>
      <span
        id="Enter_you_e-mail"
        style={{
          color: "#000000ff",
          fontFamily: "Inter",
          fontSize: "25.0px",
          fontWeight: "400",
          lineHeight: "120%",
          textAlign: "left",
          height: "46.0px",
          width: "370.0px",
          position: "absolute",
          left: "92.0px",
          top: "467.0px",
          opacity: "0.20000000298023224",
        }}
      >
        Enter you e-mail
      </span>
      <span
        id="Enter_you_password"
        style={{
          color: "#000000ff",
          fontFamily: "Inter",
          fontSize: "25.0px",
          fontWeight: "400",
          lineHeight: "120%",
          textAlign: "left",
          height: "46.0px",
          width: "370.0px",
          position: "absolute",
          left: "92.0px",
          top: "598.0px",
          opacity: "0.20000000298023224",
        }}
      >
        Enter you password
      </span>
      <div
        id="_9_51_image_1"
        style={{
          position: "absolute",
          background:
            "url(https://mabel-cdn.platui.com/api/v1/transform/s3?projectId=a9ad257e-3683-40a9-bd79-f84fcc135391&imageHash=3636658fee3fc7bfba77b486a91a819cb7cd8d3e&imageTransform=0.511502563953,0.000000000000,0.361486405134;0.000000000000,0.966666817665,0.033333342522) 100% / cover no-repeat",
          borderColor: "#000000ff",
          borderStyle: "solid",
          borderWidth: "1px",
          borderRadius: "10px",
          height: "1037.0px",
          width: "823.0px",
          left: "615.0px",
          top: "-7.0px",
          opacity: "0.9100000262260437",
        }}
      ></div>

      <div
        id="_13_112_check_box_outline_blank"
        onClick={() => navigate("/Desktop5")}
        style={{
          position: "absolute",
          height: "30.0px",
          width: "30.0px",
          left: "70.0px",
          top: "687.0px",
          cursor: "pointer",
        }}
      >
        <img
          id="I13_"
          src="assets/images/26790273065.svg"
          alt="icon"
          style={{
            position: "absolute",
            left: "calc(100% * 0.12499999205271403)",
            top: "calc(100% * 0.12499999205271403)",
          }}
        />
      </div>

      <div
        id="_10_55_eye_1"
        onClick={() => navigate("/Desktop4")}
        style={{
          position: "absolute",
          background:
            "url(assets/images/aebbb59130c13273a4c5d6535c3b99e341883c2f) 100% / cover no-repeat",
          height: "51.0px",
          width: "51.0px",
          left: "436.0px",
          top: "596.0px",
          opacity: "0.4000000059604645",
          cursor: "pointer",
        }}
      ></div>

      <span
        id="Login"
        style={{
          color: "#ffffffff",
          fontFamily: "Inter",
          fontSize: "30.0px",
          fontWeight: "400",
          textAlign: "center",
          height: "39.0px",
          width: "324.0px",
          position: "absolute",
          left: "127.0px",
          top: "777.0px",
        }}
      >
        Login
      </span>
    </div>
  );
};

export default GeneratedComponent;
